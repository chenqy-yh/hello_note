CREATE TRIGGER update_note_content_on_update  AFTER UPDATE ON data WHEN old.mime_type='vnd.android.cursor.item/text_note' BEGIN  UPDATE note   SET snippet=new.content  WHERE _id=new.note_id; END;

