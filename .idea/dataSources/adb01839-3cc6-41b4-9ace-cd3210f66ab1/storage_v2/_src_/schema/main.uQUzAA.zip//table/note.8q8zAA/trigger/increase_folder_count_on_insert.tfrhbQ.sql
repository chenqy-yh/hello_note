CREATE TRIGGER increase_folder_count_on_insert  AFTER INSERT ON note BEGIN   UPDATE note   SET notes_count=notes_count + 1  WHERE _id=new.parent_id; END;

