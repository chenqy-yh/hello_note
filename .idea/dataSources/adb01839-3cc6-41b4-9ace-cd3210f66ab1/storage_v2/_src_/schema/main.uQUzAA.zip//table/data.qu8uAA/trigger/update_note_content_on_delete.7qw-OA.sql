CREATE TRIGGER update_note_content_on_delete  AFTER delete ON data WHEN old.mime_type='vnd.android.cursor.item/text_note' BEGIN  UPDATE note   SET snippet=''  WHERE _id=old.note_id; END;

