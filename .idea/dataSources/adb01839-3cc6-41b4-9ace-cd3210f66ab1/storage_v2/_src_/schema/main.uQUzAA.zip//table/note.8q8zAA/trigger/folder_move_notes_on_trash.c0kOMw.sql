CREATE TRIGGER folder_move_notes_on_trash  AFTER UPDATE ON note WHEN new.parent_id=-3 BEGIN  UPDATE note   SET parent_id=-3  WHERE parent_id=old._id; END;

