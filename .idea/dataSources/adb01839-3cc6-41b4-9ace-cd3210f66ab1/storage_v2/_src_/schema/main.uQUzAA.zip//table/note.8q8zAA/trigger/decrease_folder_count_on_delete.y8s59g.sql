CREATE TRIGGER decrease_folder_count_on_delete  AFTER DELETE ON note BEGIN   UPDATE note   SET notes_count=notes_count-1  WHERE _id=old.parent_id  AND notes_count>0; END;

