CREATE TRIGGER folder_delete_notes_on_delete  AFTER DELETE ON note BEGIN  DELETE FROM note   WHERE parent_id=old._id; END;

