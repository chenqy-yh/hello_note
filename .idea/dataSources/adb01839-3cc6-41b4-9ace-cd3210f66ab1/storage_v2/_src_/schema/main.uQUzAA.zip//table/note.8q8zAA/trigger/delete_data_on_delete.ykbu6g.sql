CREATE TRIGGER delete_data_on_delete  AFTER DELETE ON note BEGIN  DELETE FROM data   WHERE note_id=old._id; END;

